/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplicationtable;

/**
 *
 * @author DETH
 */
public class Multiplicationtable {

    
    public static void main(String[] args) {
        printTable(15);
        System.out.println();
        printSquares(10);
        System.out.println();
        printSquaresWithWhile(10);
    }//end of main

    public static void printValue(int x) {
        System.out.printf("%4d", x);
    }

    public static void printTable(int sizeOfTable) {
        int i, j;
        for (j = 1; j <= sizeOfTable; j += 1) {
            for (i = 1; i <= sizeOfTable; i = i + 1) {
                printValue(i * j);
            }//end of for, i
            System.out.println();
        }//end of for, j
    }//end of printTable

    public static void printSquares(int N) {
        int R = 1;
        int i;
        for ( i = 1; i <= N + 1; i++) {
//           System.out.println(i * i);
            System.out.println(R);
            R += i + i + 1;
        }
    }
    
    public static void printSquaresWithWhile(int N) {
        int R = 0;
        int i = 0; 
        while(i  < N ) {
            R += i+++i;
            System.out.println(R);
        }
    }
    
    
}
